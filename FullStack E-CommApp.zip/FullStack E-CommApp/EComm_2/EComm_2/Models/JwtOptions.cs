﻿// JwtOptions.cs
namespace EComm_2
{
    public class JwtOptions
    {
        public string Key { get; set; }
        public string Issuer { get; set; }
    }
}
